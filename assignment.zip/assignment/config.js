module.exports = {
    database: {
        // Update these values after installing MySQL
        host: 'localhost',      // Usually 'localhost' or '127.0.0.1'
        user: 'root',          // Default MySQL user
        password: 'Suresh@1234',          // Set this to your MySQL root password after installation
        database: 'school_management'
    },
    port: 3000
}; 